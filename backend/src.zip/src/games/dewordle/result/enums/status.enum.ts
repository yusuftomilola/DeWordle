// export enum Status {
//   WON = 'won',
//   LOST = 'lost',
// }
