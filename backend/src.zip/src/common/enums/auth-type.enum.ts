export enum AuthType {
  Bearer = 'Bearer',
  None = 'None',
}
