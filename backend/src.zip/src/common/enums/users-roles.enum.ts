export enum UserRole {
  Admin = 'Admin',
  SubAdmin = 'SubAdmin',
  User = 'User',
  Guest = 'Guest',
}
